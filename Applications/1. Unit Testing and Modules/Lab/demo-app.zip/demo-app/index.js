const calc = require('./calculator');

console.log(calc.sum(10,20));