require('chai').should()
const calc = require('../calculator');

describe('Calc Division', function() {
    it('Should return positive number when dividing two positive numbers', () => {
        let result = calc.divide(10, 2);
        
        // assert.equal(result, 20);
        // expect(result).to.equal(20);
        result.should.equal(5);
    });
});